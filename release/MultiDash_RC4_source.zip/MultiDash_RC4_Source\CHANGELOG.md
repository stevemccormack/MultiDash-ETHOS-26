# RC4

- Added responsive main, in-flight, and post-flight displays.
- Added tower and dial battery styles with automatic percentage calculation.
- Added configurable current, RPM, link, and four telemetry fields.
- Added persistent flight counting for flights lasting at least 15 seconds.
- Added editable flight count in widget settings and both dashboard summaries.
- Added nine complete languages with radio-safe critical labels.
- Added dark and light themes.
- Split configuration, persistence, translations, and summary code into lazy modules.
- Removed the obsolete timer source, redundant flight state, dead functions, and unused translations.
- Reduced temporary allocations during configuration and model-file loading.
- Added integration, layout, locale, persistence, and flight-count regression tests.
