# MultiDash RC4

First full public release of MultiDash for ETHOS 26.

## Highlights

- Pre-flight, in-flight, and color-coded flight-summary screens
- Battery tower and dial displays with 1S-12S percentage calculation
- Experimental 0-100% fuel gauge
- Link quality, current, RPM, and four configurable telemetry fields
- Four configurable in-flight fields
- Automatic flight timer and persistent flight count
- Adjustable thresholds and high-is-good or low-is-good scoring
- Per-model settings, model images, dark/light themes, and nine languages
- UMX/DSM Flight Log and TW telemetry support through generic ETHOS sensor selection

## Install

Download `release/MultiDash_RC4_universal_install.zip` and extract it into the
SD card `scripts` directory. The final path must be:

```text
scripts/MultiDash/main.lua
```

ETHOS 26.1.0 RC4 or later is required.
